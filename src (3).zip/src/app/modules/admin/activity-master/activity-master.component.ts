import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-master',
  templateUrl: './activity-master.component.html',
  styleUrls: ['./activity-master.component.scss']
})
export class ActivityMasterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
