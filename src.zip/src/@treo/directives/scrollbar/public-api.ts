export * from '@treo/directives/scrollbar/scrollbar.directive';
export * from '@treo/directives/scrollbar/scrollbar.module';
