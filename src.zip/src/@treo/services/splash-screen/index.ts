export * from '@treo/services/splash-screen/public-api';
