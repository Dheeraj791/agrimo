export * from '@treo/services/splash-screen/splash-screen.module';
export * from '@treo/services/splash-screen/splash-screen.service';
