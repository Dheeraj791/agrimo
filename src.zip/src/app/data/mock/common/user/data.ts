/* tslint:disable:max-line-length */
export const user: any = {
    id    : 'cfaad35d-07a3-4447-a6c3-d8c3d54fd5df',
    name  : 'Abhilash Tiari',
    email : 'abhilash@agrieasy.com',
    avatar: 'assets/images/avatars/andrew-watkins.jpg',
    status: 'online'
};
