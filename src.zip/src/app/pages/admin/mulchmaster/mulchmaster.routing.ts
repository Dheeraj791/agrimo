import { Route } from '@angular/router';
import { MulchmasterComponent } from '../mulchmaster/mulchmaster.component';

export const mulchMasterRoute: Route[] = [
    {
        path     : '',
        component: MulchmasterComponent
    }
];
