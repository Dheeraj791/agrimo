import { Route } from '@angular/router';
import { IrrigationmasterComponent } from '../irrigationmaster/irrigationmaster.component';

export const irrigationMasterRoute: Route[] = [
    {
        path     : '',
        component: IrrigationmasterComponent
    }
];
