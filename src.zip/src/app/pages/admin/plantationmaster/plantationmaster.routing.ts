import { Route } from '@angular/router';

import { PlantationmasterComponent } from '../plantationmaster/plantationmaster.component';

export const plantationMasterRoute: Route[] = [
    {
        path     : '',
        component: PlantationmasterComponent
    }
];
