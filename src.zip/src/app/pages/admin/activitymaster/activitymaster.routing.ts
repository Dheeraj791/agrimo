import { Route } from '@angular/router';
import { ActivitymasterComponent } from '../activitymaster/activitymaster.component';

export const activatemasterRoute: Route[] = [
    {
        path     : '',
        component: ActivitymasterComponent
    }
];
