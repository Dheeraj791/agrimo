import { Route } from '@angular/router';
import { SoilmasterComponent } from '../soilmaster/soilmaster.component';
export const soilmasterRoute: Route[] = [
    {
        path     : '',
        component: SoilmasterComponent
    }
];
