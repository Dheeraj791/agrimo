import { Route } from '@angular/router';
import { LocationmasterComponent } from '../locationmaster/locationmaster.component';

export const locationMasterRoute: Route[] = [
    {
        path     : '',
        component: LocationmasterComponent
    }
];
