import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketvendors',
  templateUrl: './marketvendors.component.html',
  styleUrls: ['./marketvendors.component.scss']
})
export class MarketvendorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
