import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-installfpo',
  templateUrl: './installfpo.component.html',
  styleUrls: ['./installfpo.component.scss']
})
export class InstallfpoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
