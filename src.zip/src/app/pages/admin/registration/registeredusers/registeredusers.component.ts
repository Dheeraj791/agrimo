import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registeredusers',
  templateUrl: './registeredusers.component.html',
  styleUrls: ['./registeredusers.component.scss']
})
export class RegisteredusersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
