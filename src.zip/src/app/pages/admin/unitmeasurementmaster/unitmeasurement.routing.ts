import { Route } from '@angular/router';
import { UnitmeasurementmasterComponent } from '../unitmeasurementmaster/unitmeasurementmaster.component';
export const unitmeasurementmasterRoute: Route[] = [
    {
        path     : '',
        component: UnitmeasurementmasterComponent
    }
];
