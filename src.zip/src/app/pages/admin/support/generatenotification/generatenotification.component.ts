import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generatenotification',
  templateUrl: './generatenotification.component.html',
  styleUrls: ['./generatenotification.component.scss']
})
export class GeneratenotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
