import { Route } from '@angular/router';

import { QamasterComponent } from '../qamaster/qamaster.component';
export const qamasterRoute: Route[] = [
    {
        path     : '',
        component: QamasterComponent
    }
];
