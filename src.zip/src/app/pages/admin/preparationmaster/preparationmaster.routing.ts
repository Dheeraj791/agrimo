import { Route } from '@angular/router';

import { PreparationmasterComponent } from '../preparationmaster/preparationmaster.component';

export const preparationMasterRoute: Route[] = [
    {
        path     : '',
        component: PreparationmasterComponent
    }
];
