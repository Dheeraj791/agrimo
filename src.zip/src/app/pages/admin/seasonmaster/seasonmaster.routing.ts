import { Route } from '@angular/router';

import { SeasonmasterComponent } from '../seasonmaster/seasonmaster.component';
export const seasonmasterRoute: Route[] = [
    {
        path     : '',
        component: SeasonmasterComponent
    }
];
